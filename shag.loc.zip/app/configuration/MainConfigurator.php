<?php
/**
 * Created by PhpStorm.
 * User: mamedov
 * Date: 13.09.2018
 * Time: 20:19
 */

namespace app\configuration;


class MainConfigurator
{
    const TEMPLATE_CACHE = false;
}