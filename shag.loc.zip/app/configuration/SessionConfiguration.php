<?php
/**
 * Created by PhpStorm.
 * User: mamedov
 * Date: 25.09.2018
 * Time: 20:14
 */

namespace app\configuration;


class SessionConfiguration
{
    const COOKIE_KEY = "fdasgdf";
    const SESSION_TIME = 3600;
}