<?php

namespace app\controllers;

use app\models\Role;
use app\models\User;
use core\base\Controller;
use core\base\View;
use core\system\Auth;
use core\system\Session;

class Main extends Controller
{
    public function action_index()
    {
        $v = new View("main");
        $v->auth=Auth::instance()->isAuth();
        $v->user=Auth::instance()->getCurrentUser();
        if($v->auth)
            $v->isAdmin = User::where("id",Session::instance()->getUserId())->first()->hasRole("admin");
        $v->setTemplate();
        echo $v->render();

       //echo "<pre>";
       //var_dump(User::where("id",1)->first()->roles()->all());
       //var_dump(User::where("id",1)->first()->hasRole("admin"));
    }

}