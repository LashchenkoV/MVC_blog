<?php
namespace core\system\exceptions;
class RouterException extends \Exception
{

}