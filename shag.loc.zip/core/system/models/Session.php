<?php
/**
 * Created by PhpStorm.
 * User: mamedov
 * Date: 25.09.2018
 * Time: 20:26
 */

namespace core\system\models;


use core\base\Model;

class Session extends Model{

}