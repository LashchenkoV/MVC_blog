<?php

namespace core\base;
abstract class Controller
{

}